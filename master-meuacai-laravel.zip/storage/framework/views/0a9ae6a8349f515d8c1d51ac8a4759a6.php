

<?php $__env->startSection('title', 'Produtos e Pontos'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
<link rel="stylesheet" href="<?php echo e(asset('css/profile/profile.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" crossorigin="anonymous" />

<div class="container mt-4">
    <div class="row justify-content-between">
        <?php echo $__env->make('layouts.components.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-9">
            <div class="container mt-4">
                <h1 class="text-center mb-4">
                    <i class="bi bi-box-seam"></i> Produtos e Pontos
                </h1>
                <h2 class="mt-5 mb-4">Todos os Produtos</h2>

                <div class="d-flex justify-content-end mb-4">
                    <a href="<?php echo e(route('profile.products.create')); ?>" class="btn btn-success">
                        <i class="bi bi-plus-lg"></i> Criar Novo Produto
                    </a>
                </div>

                <?php if($products->isEmpty()): ?>
                    <div class="alert alert-warning text-center">
                        Não há produtos cadastrados. Cadastre um ponto e insira o produto, ou edite.
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-4">
                                <div class="card shadow-sm">
                                    <div class="card-body position-relative">
                                        <?php if($product->image && Storage::disk('public')->exists($product->image)): ?>
                                            <img src="<?php echo e(Storage::disk('public')->url($product->image)); ?>" alt="Imagem do Produto" id="product-image" class="img-thumbnail mt-2">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/default-product.png')); ?>" alt="Imagem padrão do Produto" id="product-image" class="img-thumbnail mt-2">
                                        <?php endif; ?>
                                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                        <p class="card-text">
                                            <strong>Preço:</strong> R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?><br>
                                            <strong>Quantidade:</strong> <?php echo e($product->quantity); ?><br>
                                            <strong>Descrição:</strong> <?php echo e($product->description); ?><br>
                                            <strong>Ponto:</strong> <?php echo e($product->point->name ?? 'Nenhum ponto associado'); ?><br>
                                            <?php if($product->point): ?>
                                                <strong>Endereço do Ponto:</strong> <?php echo e($product->point->endereco->logradouro); ?>, <?php echo e($product->point->endereco->numero); ?>, <?php echo e($product->point->endereco->bairro); ?><br>
                                            <?php endif; ?>
                                        </p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <a href="<?php echo e(route('profile.products.edit', $product->id)); ?>" class="btn btn-outline-primary btn-sm">
                                                <i class="bi bi-pencil"></i> Editar
                                            </a>
                                            <form action="<?php echo e(route('profile.products.destroy', $product->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Você tem certeza que deseja excluir este produto?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger btn-sm">
                                                    <i class="bi bi-trash"></i> Excluir
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex justify-content-center mt-4">
                        <nav aria-label="Page navigation">
                            <ul class="pagination pagination-lg">
                                <?php if($products->onFirstPage()): ?>
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php $__currentLoopData = $products->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $products->currentPage()): ?>
                                        <li class="page-item active"><a class="page-link" href="#"><?php echo e($page); ?></a></li>
                                    <?php else: ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if($products->hasMorePages()): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/manager/popgen.js')); ?>"></script>
<script src="<?php echo e(asset('js/maps/prevent.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/meuaca14/public_html/resources/views/profile/manager/manager-products.blade.php ENDPATH**/ ?>