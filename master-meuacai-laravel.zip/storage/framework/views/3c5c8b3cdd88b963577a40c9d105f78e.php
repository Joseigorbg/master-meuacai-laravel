

<?php $__env->startSection('title', 'Gerenciamento de Pontos'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
<link rel="stylesheet" href="<?php echo e(asset('css/profile/profile.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" crossorigin="anonymous" />

<div class="container mt-4">
    <div class="row justify-content-between">
        <?php echo $__env->make('layouts.components.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-9">
            <div class="container mt-4">
                <h1 class="text-center mb-4">
                    <i class="bi bi-tools"></i> Gerenciamento de Pontos
                </h1>
                <h2 class="mt-5 mb-4">Seus Pontos</h2>
                
                <!-- Botão para criar um novo ponto -->
                <div class="d-flex justify-content-end mt-2 mb-4">
                    <a href="<?php echo e(route('auth.profile')); ?>" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i> Adicionar Novo Ponto
                    </a>
                </div>

                <?php if($points->isEmpty()): ?>
                    <div class="alert alert-warning text-center">
                        Não há pontos cadastrados. Adicione um novo ponto.
                    </div>
                <?php else: ?>
                    <div class="row">
                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5 class="card-title mb-0"><?php echo e($point->name); ?></h5>
                                        <?php
                                            $status = $point->complemento->first()->status ?? 0;
                                        ?>
                                        <span class="badge <?php echo e($status == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                                            <?php echo e($status == 1 ? 'Ativo' : 'Inativo'); ?>

                                        </span>
                                    </div>
                                    
                                    <p class="mb-1"><strong>Endereço:</strong> <?php echo e($point->endereco->logradouro); ?>, <?php echo e($point->endereco->numero); ?> - <?php echo e($point->endereco->bairro); ?>, <?php echo e($point->endereco->cidade); ?> - <?php echo e($point->endereco->estado); ?></p>
                                    <p class="mb-1"><strong>CEP:</strong> <?php echo e($point->endereco->cep); ?></p>
                                    <p class="mb-1"><strong>Telefone:</strong> <?php echo e($point->tel_contato); ?></p>                    

                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <a href="<?php echo e(route('points.edit', $point)); ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="bi bi-gear-fill"></i> Editar
                                        </a>
                                        <form action="<?php echo e(route('points.destroy', $point)); ?>" method="POST" class="d-inline" onsubmit="return confirmDelete()">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm">
                                                <i class="bi bi-trash"></i> Excluir
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex justify-content-center mt-4">
                        <nav aria-label="Page navigation">
                            <ul class="pagination pagination-lg">
                                <!-- Link para a página anterior -->
                                <?php if($points->onFirstPage()): ?>
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($points->previousPageUrl()); ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <!-- Links para cada página -->
                                <?php $__currentLoopData = $points->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $points->currentPage()): ?>
                                        <li class="page-item active"><a class="page-link" href="#"><?php echo e($page); ?></a></li>
                                    <?php else: ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Link para a próxima página -->
                                <?php if($points->hasMorePages()): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($points->nextPageUrl()); ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/manager/popgen.js')); ?>"></script>
<script src="<?php echo e(asset('js/maps/prevent.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/meuaca14/public_html/resources/views/profile/manager/manager-point.blade.php ENDPATH**/ ?>