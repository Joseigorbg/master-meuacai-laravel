<?php

namespace App\Http\Controllers\Products;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Point;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::with(['point', 'user'])->paginate(10);
        return view('profile.manager.manager-products', compact('products'));
    }

    public function create()
    {
        $points = Point::where('user_id', auth()->id())->get();
        return view('profile.products.create', compact('points'));
    }

    public function show($id)
    {
        $product = Product::with(['point', 'user'])->findOrFail($id);
        return response()->json($product);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'products.*.name' => 'required|string|max:255',
            'products.*.price' => 'required|numeric',
            'products.*.quantity' => 'required|integer',
            'products.*.description' => 'nullable|string',
            'products.*.image' => 'nullable|image|max:2048',
            'products.*.ponto_id_fk' => 'required|exists:points,id',
        ]);

        foreach ($request->products as $productData) {
            if (isset($productData['image'])) {
                // Armazena a imagem no diretório correto
                $imagePath = $productData['image']->store('complementos/images', 'public');
                $productData['image'] = $imagePath;
            }

            $productData['user_id'] = auth()->id();
            Product::create($productData);
        }

        return redirect()->route('profile.manager.products')
            ->with('success', 'Produtos cadastrados com sucesso!');
    }

    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'name' => 'sometimes|string|max:255',
            'price' => 'sometimes|numeric',
            'quantity' => 'sometimes|integer',
            'description' => 'nullable|string',
            'image' => 'nullable|image|max:2048',
        ]);

        $product = Product::findOrFail($id);

        if ($request->hasFile('image')) {
            // Remove a imagem antiga, se existir
            if ($product->image) {
                Storage::disk('public')->delete($product->image);
            }

            // Armazena a nova imagem
            $imagePath = $request->file('image')->store('complementos/images', 'public');
            $validatedData['image'] = $imagePath;
        }

        $product->update($validatedData);

        return redirect()->route('profile.manager.products')
            ->with('success', 'Produto atualizado com sucesso!');
    }

    public function edit(Product $product)
    {
        $this->authorize('update', $product);

        $points = Point::where('user_id', auth()->id())->get();

        return view('profile.products.edit-product', compact('product', 'points'));
    }

    public function destroy(Product $product)
    {
        $this->authorize('delete', $product);

        // Remove a imagem associada ao produto antes de excluí-lo
        if ($product->image) {
            Storage::disk('public')->delete($product->image);
        }

        $product->delete();

        return redirect()->route('profile.manager.products')->with('success', 'Produto excluído com sucesso!');
    }
}
