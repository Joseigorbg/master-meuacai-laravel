<div class="like-button-container">
    <button id="like-button" class="btn btn-primary like-btn">
        Curtir <span id="like-count">{{ $likes_count }}</span>
    </button>
</div>

